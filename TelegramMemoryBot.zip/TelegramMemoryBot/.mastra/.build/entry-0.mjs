import { Mastra } from '@mastra/core';
import { MastraError } from '@mastra/core/error';
import { PinoLogger } from '@mastra/loggers';
import { MastraLogger, LogLevel } from '@mastra/core/logger';
import pino from 'pino';
import { MCPServer } from '@mastra/mcp';
import { Inngest, NonRetriableError } from 'inngest';
import { z } from 'zod';
import { PostgresStore } from '@mastra/pg';
import { realtimeMiddleware } from '@inngest/realtime';
import { serve, init } from '@mastra/inngest';
import { openai } from '@ai-sdk/openai';
import { Agent } from '@mastra/core/agent';
import { Memory } from '@mastra/memory';

const sharedPostgresStorage = new PostgresStore({
  connectionString: process.env.DATABASE_URL || "postgresql://localhost:5432/mastra"
});

const inngest = new Inngest(
  process.env.NODE_ENV === "production" ? {
    id: "replit-agent-workflow",
    name: "Replit Agent Workflow System"
  } : {
    id: "mastra",
    baseUrl: "http://localhost:3000",
    isDev: true,
    middleware: [realtimeMiddleware()]
  }
);

const {
  createWorkflow: originalCreateWorkflow,
  createStep} = init(inngest);
function createWorkflow(params) {
  return originalCreateWorkflow({
    ...params,
    retryConfig: {
      attempts: process.env.NODE_ENV === "production" ? 3 : 0,
      ...params.retryConfig ?? {}
    }
  });
}
const inngestFunctions = [];
function inngestServe({
  mastra,
  inngest: inngest2
}) {
  let serveHost = void 0;
  if (process.env.NODE_ENV === "production") {
    if (process.env.REPLIT_DOMAINS) {
      serveHost = `https://${process.env.REPLIT_DOMAINS.split(",")[0]}`;
    }
  } else {
    serveHost = "http://localhost:5000";
  }
  return serve({
    mastra,
    inngest: inngest2,
    functions: inngestFunctions,
    registerOptions: { serveHost }
  });
}

const telegramAgent = new Agent({
  name: "Telegram Bot",
  instructions: `
    You are a friendly and helpful AI assistant on Telegram.
    
    Your role is to:
    - Have natural, engaging conversations with users
    - Remember past conversations and context from previous messages
    - Be helpful, informative, and personable
    - Ask clarifying questions when needed
    - Provide thoughtful and relevant responses
    
    When responding:
    - Keep messages conversational and natural
    - Reference previous parts of the conversation when relevant
    - Be concise but thorough
    - Show personality while being professional
    
    Remember: Each user has their own conversation thread, so you can build
    ongoing relationships and remember what you've discussed with each person.
  `,
  model: openai("gpt-4o"),
  /**
   * PostgreSQL memory storage for persistent conversation history
   * This allows the agent to remember conversations across sessions
   */
  memory: new Memory({
    storage: new PostgresStore({
      connectionString: process.env.DATABASE_URL || "postgresql://localhost:5432/mastra"
    })
  })
});

const generateResponse = createStep({
  id: "generate-response",
  description: "Generate AI response using telegram agent with memory",
  inputSchema: z.object({
    chatId: z.union([z.string(), z.number()]).describe("Telegram chat ID"),
    userName: z.string().describe("Username of the person sending the message"),
    message: z.string().describe("The message text from the user")
  }),
  outputSchema: z.object({
    chatId: z.union([z.string(), z.number()]),
    response: z.string()
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F680} [generateResponse] Starting step", {
      chatId: inputData.chatId,
      userName: inputData.userName,
      messageLength: inputData.message.length
    });
    logger?.info("\u{1F916} [generateResponse] Calling agent with memory");
    const result = await telegramAgent.generateLegacy(
      [
        {
          role: "user",
          content: inputData.message
        }
      ],
      {
        memory: {
          thread: {
            id: `telegram-${inputData.chatId}`,
            metadata: {
              userName: inputData.userName,
              platform: "telegram"
            }
          },
          resource: `user-${inputData.chatId}`
        }
      }
    );
    logger?.info("\u2705 [generateResponse] Agent response generated", {
      responseLength: result.text.length
    });
    return {
      chatId: inputData.chatId,
      response: result.text
    };
  }
});
const sendResponse = createStep({
  id: "send-response",
  description: "Send the AI response back to the user on Telegram",
  inputSchema: z.object({
    chatId: z.union([z.string(), z.number()]),
    response: z.string()
  }),
  outputSchema: z.object({
    success: z.boolean(),
    messageId: z.number().optional(),
    error: z.string().optional()
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4E4} [sendResponse] Starting step", {
      chatId: inputData.chatId,
      responseLength: inputData.response.length
    });
    const botToken = process.env.TELEGRAM_BOT_TOKEN;
    if (!botToken) {
      logger?.error("\u274C [sendResponse] TELEGRAM_BOT_TOKEN not found");
      return {
        success: false,
        error: "TELEGRAM_BOT_TOKEN not configured"
      };
    }
    try {
      logger?.info("\u{1F4E4} [sendResponse] Sending message to Telegram API");
      const response = await fetch(
        `https://api.telegram.org/bot${botToken}/sendMessage`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            chat_id: inputData.chatId,
            text: inputData.response
          })
        }
      );
      const data = await response.json();
      if (!response.ok || !data.ok) {
        logger?.error("\u274C [sendResponse] Telegram API error", {
          status: response.status,
          data
        });
        return {
          success: false,
          error: data.description || "Failed to send message"
        };
      }
      logger?.info("\u2705 [sendResponse] Message sent successfully", {
        messageId: data.result.message_id
      });
      return {
        success: true,
        messageId: data.result.message_id
      };
    } catch (error) {
      logger?.error("\u274C [sendResponse] Exception occurred", { error });
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
});
const telegramWorkflow = createWorkflow({
  id: "telegram-bot",
  inputSchema: z.object({
    chatId: z.union([z.string(), z.number()]).describe("Telegram chat ID"),
    userName: z.string().describe("Username of the person sending the message"),
    message: z.string().describe("The message text from the user")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    messageId: z.number().optional(),
    error: z.string().optional()
  }),
  steps: [generateResponse, sendResponse]
}).then(generateResponse).then(sendResponse).commit();

class ProductionPinoLogger extends MastraLogger {
  logger;
  constructor(options = {}) {
    super(options);
    this.logger = pino({
      name: options.name || "app",
      level: options.level || LogLevel.INFO,
      base: {},
      formatters: {
        level: (label, _number) => ({
          level: label
        })
      },
      timestamp: () => `,"time":"${new Date(Date.now()).toISOString()}"`
    });
  }
  debug(message, args = {}) {
    this.logger.debug(args, message);
  }
  info(message, args = {}) {
    this.logger.info(args, message);
  }
  warn(message, args = {}) {
    this.logger.warn(args, message);
  }
  error(message, args = {}) {
    this.logger.error(args, message);
  }
}
const mastra = new Mastra({
  storage: sharedPostgresStorage,
  // Register your workflows here
  workflows: {
    telegramWorkflow
  },
  // Register your agents here
  agents: {
    telegramAgent
  },
  mcpServers: {
    allTools: new MCPServer({
      name: "allTools",
      version: "1.0.0",
      tools: {}
    })
  },
  bundler: {
    // A few dependencies are not properly picked up by
    // the bundler if they are not added directly to the
    // entrypoint.
    externals: ["@slack/web-api", "inngest", "inngest/hono", "hono", "hono/streaming"],
    // sourcemaps are good for debugging.
    sourcemap: true
  },
  server: {
    host: "0.0.0.0",
    port: 5e3,
    middleware: [async (c, next) => {
      const mastra2 = c.get("mastra");
      const logger = mastra2?.getLogger();
      logger?.debug("[Request]", {
        method: c.req.method,
        url: c.req.url
      });
      try {
        await next();
      } catch (error) {
        logger?.error("[Response]", {
          method: c.req.method,
          url: c.req.url,
          error
        });
        if (error instanceof MastraError) {
          if (error.id === "AGENT_MEMORY_MISSING_RESOURCE_ID") {
            throw new NonRetriableError(error.message, {
              cause: error
            });
          }
        } else if (error instanceof z.ZodError) {
          throw new NonRetriableError(error.message, {
            cause: error
          });
        }
        throw error;
      }
    }],
    apiRoutes: [
      // This API route is used to register the Mastra workflow (inngest function) on the inngest server
      {
        path: "/api/inngest",
        method: "ALL",
        createHandler: async ({
          mastra: mastra2
        }) => inngestServe({
          mastra: mastra2,
          inngest
        })
        // The inngestServe function integrates Mastra workflows with Inngest by:
        // 1. Creating Inngest functions for each workflow with unique IDs (workflow.${workflowId})
        // 2. Setting up event handlers that:
        //    - Generate unique run IDs for each workflow execution
        //    - Create an InngestExecutionEngine to manage step execution
        //    - Handle workflow state persistence and real-time updates
        // 3. Establishing a publish-subscribe system for real-time monitoring
        //    through the workflow:${workflowId}:${runId} channel
      }
    ]
  },
  logger: process.env.NODE_ENV === "production" ? new ProductionPinoLogger({
    name: "Mastra",
    level: "info"
  }) : new PinoLogger({
    name: "Mastra",
    level: "info"
  })
});
if (Object.keys(mastra.getWorkflows()).length > 1) {
  throw new Error("More than 1 workflows found. Currently, more than 1 workflows are not supported in the UI, since doing so will cause app state to be inconsistent.");
}
if (Object.keys(mastra.getAgents()).length > 1) {
  throw new Error("More than 1 agents found. Currently, more than 1 agents are not supported in the UI, since doing so will cause app state to be inconsistent.");
}

export { mastra };
